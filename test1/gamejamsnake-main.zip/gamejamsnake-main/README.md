# Arcade Snake game

A simple snake game made for a personal gamejam with a few friends, the theme was "retro", this was made in 20 minutes. 5 minutes was for planning, 15 minutes was used for programming, designing, and everything else.

## Local use

1. Download a copy of the repo
```bash
git clone https://github.com/3kh0/arcade-snake.git
```
2. Start a HTTP server and upload the files to it
3. Enjoy

## Contributing

This was for a simple gamejam, so I will not be merging PRs, but if you want to, you can fork it and make it better

## License

WTFPL License, tl;dr, do whatever you want

```
            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2012 Romain Lespinasse <romain.lespinasse@gmail.com>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.
```
Full copy is located in the [LICENSE](LICENSE) file